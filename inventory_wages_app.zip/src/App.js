import React, { useState, useEffect } from 'react';
import { db } from './firebase';
import { collection, addDoc, getDocs } from 'firebase/firestore';

function App() {
  const [inventory, setInventory] = useState([]);
  const [item, setItem] = useState('');
  const [quantity, setQuantity] = useState('');
  const [wages, setWages] = useState([]);
  const [staff, setStaff] = useState('');
  const [hours, setHours] = useState('');
  const [rate, setRate] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      const invSnapshot = await getDocs(collection(db, 'inventory'));
      setInventory(invSnapshot.docs.map(doc => doc.data()));

      const wageSnapshot = await getDocs(collection(db, 'wages'));
      setWages(wageSnapshot.docs.map(doc => doc.data()));
    };
    fetchData();
  }, []);

  const addInventory = async () => {
    if (!item || !quantity) return;
    const newItem = { item, quantity: parseInt(quantity) };
    await addDoc(collection(db, 'inventory'), newItem);
    setInventory([...inventory, newItem]);
    setItem('');
    setQuantity('');
  };

  const addWage = async () => {
    if (!staff || !hours || !rate) return;
    const total = parseFloat(hours) * parseFloat(rate);
    const newWage = { staff, hours, rate, total };
    await addDoc(collection(db, 'wages'), newWage);
    setWages([...wages, newWage]);
    setStaff('');
    setHours('');
    setRate('');
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Inventory</h2>
      <input placeholder="Item" value={item} onChange={e => setItem(e.target.value)} />
      <input placeholder="Quantity" type="number" value={quantity} onChange={e => setQuantity(e.target.value)} />
      <button onClick={addInventory}>Add</button>
      <ul>{inventory.map((inv, i) => <li key={i}>{inv.item} — {inv.quantity}</li>)}</ul>

      <h2>Staff Wages</h2>
      <input placeholder="Staff" value={staff} onChange={e => setStaff(e.target.value)} />
      <input placeholder="Hours" type="number" value={hours} onChange={e => setHours(e.target.value)} />
      <input placeholder="Rate/hr" type="number" value={rate} onChange={e => setRate(e.target.value)} />
      <button onClick={addWage}>Add</button>
      <ul>{wages.map((w, i) => <li key={i}>{w.staff}: {w.hours}h × ${w.rate}/hr = ${w.total}</li>)}</ul>
    </div>
  );
}

export default App;
